# MM Music Randomizer

Reads .mmrs files and randomizes music. 
